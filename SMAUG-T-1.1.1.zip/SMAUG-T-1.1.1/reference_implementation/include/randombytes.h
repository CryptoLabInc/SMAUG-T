// SPDX-License-Identifier: MIT

#ifndef SMAUGT_RANDOMBYTES_H
#define SMAUGT_RANDOMBYTES_H

#include <stddef.h>
#include <stdint.h>

int randombytes(uint8_t *x, size_t xlen);

#endif /* !SMAUGT_RANDOMBYTES_H */
