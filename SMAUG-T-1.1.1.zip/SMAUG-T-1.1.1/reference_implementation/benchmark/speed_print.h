// SPDX-License-Identifier: MIT

#ifndef SMAUGT_BENCHMARK_SPEED_PRINT_H
#define SMAUGT_BENCHMARK_SPEED_PRINT_H

#include <stddef.h>
#include <stdint.h>

void print_results(const char *s, uint64_t *t, size_t tlen);

#endif /* SMAUGT_BENCHMARK_SPEED_PRINT_H */
